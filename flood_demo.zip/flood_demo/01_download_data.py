"""Step 1: download weather + river discharge for every location (free, no API key)."""
import sys
from floodlib import *

DATA_DIR.mkdir(exist_ok=True)
ok, bad = [], []
for loc in LOCATIONS:
    f = DATA_DIR / f"{slug(loc['name'])}.csv"
    if f.exists():
        print(f"skip (already downloaded): {loc['name']}")
        ok.append(loc["name"]); continue
    try:
        df = fetch_history(loc["lat"], loc["lon"])
        d = clean(df)
        years = d["date"].dt.year.nunique()
        if years < 15 or d["discharge"].median() <= 0 or d["discharge"].nunique() < 50:
            print(f"!! no usable river at this point, skipped: {loc['name']}"); bad.append(loc["name"]); continue
        df.to_csv(f, index=False)
        print(f"ok  {loc['name']}: {len(d)} days, median flow {d['discharge'].median():.1f} m3/s")
        ok.append(loc["name"])
    except Exception as e:
        print(f"!! failed {loc['name']}: {e}"); bad.append(loc["name"])
print(f"\nDone. {len(ok)} locations ready, {len(bad)} skipped: {bad}")
