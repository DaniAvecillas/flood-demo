"""Shared code for the flood demo: locations, Open-Meteo downloads, features, predictions."""
import json
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

def _region():
    for i, a in enumerate(sys.argv):
        if a == "--region" and i + 1 < len(sys.argv):
            return sys.argv[i + 1].lower()
    return os.environ.get("FLOOD_REGION", "world").lower()


REGION = _region()                      # "world" | "canada" | "ontario"
ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"                # shared by all regions (each river is downloaded once)
MODEL_DIR = ROOT / "models" if REGION == "world" else ROOT / f"models_{REGION}"

# ---------------------------------------------------------------- settings
START_DATE, END_DATE = "2002-01-01", "2025-12-31"
TRAIN_END, VAL_END = 2017, 2021      # train <= 2017 | validation 2018-2021 | test >= 2022
FLOOD_PCT = 0.98                     # flood-risk level = this percentile of the river's own flow
HORIZON = 3                          # predict the next 1..3 days
SEQ_LEN = 14                         # LSTM looks at the last 14 days
WATCH, WARNING = 0.10, 0.30          # risk bands (probability)

# Approximate points on big rivers. The download script reports any point with no usable data.
WORLD_LOCATIONS = [
    dict(name="Kaministiquia River, Thunder Bay", country="Canada", province="ON", lat=48.40, lon=-89.30),
    dict(name="Red River, Winnipeg", country="Canada", province="MB", lat=49.90, lon=-97.12),
    dict(name="Saint John River, Fredericton", country="Canada", province="NB", lat=45.96, lon=-66.64),
    dict(name="Mississippi River, St. Louis", country="USA", lat=38.63, lon=-90.18),
    dict(name="Missouri River, Kansas City", country="USA", lat=39.11, lon=-94.60),
    dict(name="Ohio River, Cincinnati", country="USA", lat=39.10, lon=-84.51),
    dict(name="Susquehanna River, Harrisburg", country="USA", lat=40.26, lon=-76.89),
    dict(name="Sacramento River, Sacramento", country="USA", lat=38.58, lon=-121.50),
    dict(name="Rhine, Cologne", country="Germany", lat=50.94, lon=6.96),
    dict(name="Elbe, Dresden", country="Germany", lat=51.05, lon=13.74),
    dict(name="Danube, Vienna", country="Austria", lat=48.21, lon=16.40),
    dict(name="Seine, Paris", country="France", lat=48.85, lon=2.35),
    dict(name="Po, Piacenza", country="Italy", lat=45.05, lon=9.70),
    dict(name="Vistula, Warsaw", country="Poland", lat=52.23, lon=21.02),
    dict(name="Tisza, Szeged", country="Hungary", lat=46.25, lon=20.15),
    dict(name="Ganges, Patna", country="India", lat=25.61, lon=85.14),
    dict(name="Brahmaputra, Guwahati", country="India", lat=26.18, lon=91.75),
    dict(name="Indus, Sukkur", country="Pakistan", lat=27.70, lon=68.86),
    dict(name="Mekong, Phnom Penh", country="Cambodia", lat=11.57, lon=104.93),
    dict(name="Yangtze, Wuhan", country="China", lat=30.55, lon=114.29),
    dict(name="Amazon, Manaus", country="Brazil", lat=-3.14, lon=-60.02),
    dict(name="Magdalena, Barrancabermeja", country="Colombia", lat=7.07, lon=-73.85),
    dict(name="Babahoyo River, Guayas basin", country="Ecuador", lat=-1.80, lon=-79.53),
    dict(name="Murray River, Echuca", country="Australia", lat=-36.13, lon=144.75),
    dict(name="Zambezi, Tete", country="Mozambique", lat=-16.16, lon=33.59),
    dict(name="Niger, Niamey", country="Niger", lat=13.51, lon=2.11),
    dict(name="Congo, Kinshasa", country="DR Congo", lat=-4.30, lon=15.30),
]
CANADA_EXTRA = [
    # Ontario
    dict(name="Ottawa River, Ottawa", country="Canada", province="ON", lat=45.45, lon=-75.65),
    dict(name="Grand River, Brantford", country="Canada", province="ON", lat=43.14, lon=-80.26),
    dict(name="Thames River, London", country="Canada", province="ON", lat=42.98, lon=-81.25),
    dict(name="Trent River, Trenton", country="Canada", province="ON", lat=44.10, lon=-77.58),
    dict(name="Moose River, Moosonee", country="Canada", province="ON", lat=51.28, lon=-80.65),
    dict(name="Albany River, Fort Albany", country="Canada", province="ON", lat=52.20, lon=-81.60),
    dict(name="Mattagami River, Smooth Rock Falls", country="Canada", province="ON", lat=49.28, lon=-81.62),
    dict(name="Spanish River, Espanola", country="Canada", province="ON", lat=46.25, lon=-81.77),
    dict(name="Rainy River, Fort Frances", country="Canada", province="ON", lat=48.60, lon=-93.40),
    # rest of Canada
    dict(name="Fraser River, Hope", country="Canada", province="BC", lat=49.38, lon=-121.45),
    dict(name="Columbia River, Revelstoke", country="Canada", province="BC", lat=51.00, lon=-118.20),
    dict(name="Skeena River, Terrace", country="Canada", province="BC", lat=54.52, lon=-128.60),
    dict(name="South Saskatchewan River, Saskatoon", country="Canada", province="SK", lat=52.12, lon=-106.67),
    dict(name="Athabasca River, Fort McMurray", country="Canada", province="AB", lat=56.73, lon=-111.38),
    dict(name="Peace River, Peace River", country="Canada", province="AB", lat=56.24, lon=-117.29),
    dict(name="Mackenzie River, Fort Simpson", country="Canada", province="NT", lat=61.86, lon=-121.35),
    dict(name="Saint-Maurice River, Trois-Rivieres", country="Canada", province="QC", lat=46.35, lon=-72.55),
    dict(name="Saguenay River, Chicoutimi", country="Canada", province="QC", lat=48.42, lon=-71.07),
    dict(name="Miramichi River, Miramichi", country="Canada", province="NB", lat=47.03, lon=-65.47),
]
ALL_LOCATIONS = WORLD_LOCATIONS + CANADA_EXTRA
if REGION == "canada":
    LOCATIONS = [l for l in ALL_LOCATIONS if l["country"] == "Canada"]
elif REGION == "ontario":
    LOCATIONS = [l for l in ALL_LOCATIONS if l.get("province") == "ON"]
else:
    LOCATIONS = WORLD_LOCATIONS
REGION_TITLE = {"world": "World", "canada": "Canada", "ontario": "Ontario"}.get(REGION, REGION.title())
LOC_BY_NAME = {l["name"]: l for l in ALL_LOCATIONS}


def slug(name):
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


# ---------------------------------------------------------------- Open-Meteo
WEATHER_VARS = "precipitation_sum,rain_sum,snowfall_sum,temperature_2m_mean,wind_gusts_10m_max"
RENAME = {"precipitation_sum": "precip", "rain_sum": "rain", "snowfall_sum": "snow",
          "temperature_2m_mean": "tmean", "wind_gusts_10m_max": "gust"}


def _get(url, params, tries=6):
    for k in range(tries):
        try:
            r = requests.get(url, params=params, timeout=60)
            if r.status_code == 200:
                return r.json()
            if r.status_code in (429, 500, 502, 503, 504):
                time.sleep(5 * (k + 1))
                continue
            raise RuntimeError(f"Open-Meteo error {r.status_code}: {r.text[:200]}")
        except requests.RequestException:
            time.sleep(3 * (k + 1))
    raise RuntimeError("Open-Meteo request failed after several tries")


def _daily_frame(j, rename=None):
    df = pd.DataFrame(j["daily"])
    df["date"] = pd.to_datetime(df.pop("time"))
    return df.rename(columns=rename or {})


def _year_chunks(start, end, step=8):
    y0, y1 = int(start[:4]), int(end[:4])
    for a in range(y0, y1 + 1, step):
        b = min(a + step - 1, y1)
        yield (start if a == y0 else f"{a}-01-01"), (end if b == y1 else f"{b}-12-31")


def fetch_history(lat, lon, start=START_DATE, end=END_DATE):
    """Daily weather (ERA5) + simulated river discharge (GloFAS) from Open-Meteo, 2002-2025."""
    w_parts, q_parts = [], []
    for a, b in _year_chunks(start, end):
        w = _get("https://archive-api.open-meteo.com/v1/archive", dict(
            latitude=lat, longitude=lon, start_date=a, end_date=b,
            daily=WEATHER_VARS, timezone="UTC"))
        w_parts.append(_daily_frame(w, RENAME))
        time.sleep(0.5)
        q = _get("https://flood-api.open-meteo.com/v1/flood", dict(
            latitude=lat, longitude=lon, start_date=a, end_date=b, daily="river_discharge"))
        q_parts.append(_daily_frame(q, {"river_discharge": "discharge"}))
        time.sleep(0.5)
    return pd.concat(w_parts).merge(pd.concat(q_parts), on="date", how="inner")


def fetch_recent(lat, lon, days=40):
    """Last `days` days up to today (live demo)."""
    w = _get("https://api.open-meteo.com/v1/forecast", dict(
        latitude=lat, longitude=lon, daily=WEATHER_VARS, past_days=days,
        forecast_days=1, timezone="UTC"))
    q = _get("https://flood-api.open-meteo.com/v1/flood", dict(
        latitude=lat, longitude=lon, daily="river_discharge", past_days=days, forecast_days=1))
    return _daily_frame(w, RENAME).merge(
        _daily_frame(q, {"river_discharge": "discharge"}), on="date", how="inner")


# ---------------------------------------------------------------- features
def clean(df):
    d = df.sort_values("date").drop_duplicates("date").reset_index(drop=True)
    d["discharge"] = d["discharge"].interpolate(limit=5)
    for c in ["precip", "rain", "snow"]:
        d[c] = d[c].fillna(0).clip(lower=0)
    for c in ["tmean", "gust"]:
        d[c] = d[c].interpolate(limit=5)
    return d.dropna(subset=["discharge", "tmean", "gust"]).reset_index(drop=True)


def compute_threshold(d):
    """Flood-risk level of THIS river = percentile of its own flow, using training years only."""
    return float(d.loc[d["date"].dt.year <= TRAIN_END, "discharge"].quantile(FLOOD_PCT))


XGB_FEATURES = [
    "q_ratio", "q_lag1", "q_lag2", "q_lag3", "dq1", "dq3", "qmax3", "qmean7",
    "precip", "precip_3", "precip_7", "precip_14", "rain_3", "snow_7", "snow_14",
    "tmean", "tmean_3", "tmean_7", "gust", "melt_index", "doy_sin", "doy_cos", "lat_n"]
SEQ_COLS = ["q_log", "precip_l", "rain_l", "snow_l", "tmean", "gust", "doy_sin", "doy_cos", "lat_n"]


def make_features(d, thr, lat):
    d = d.copy().reset_index(drop=True)
    q = d["discharge"] / thr                       # 1.0 = the flood-risk level
    d["q_ratio"] = q
    for k in (1, 2, 3):
        d[f"q_lag{k}"] = q.shift(k)
    d["dq1"], d["dq3"] = q - q.shift(1), q - q.shift(3)
    d["qmax3"], d["qmean7"] = q.rolling(3).max(), q.rolling(7).mean()
    for n in (3, 7, 14):
        d[f"precip_{n}"] = d["precip"].rolling(n).sum()
    d["rain_3"] = d["rain"].rolling(3).sum()
    d["snow_7"], d["snow_14"] = d["snow"].rolling(7).sum(), d["snow"].rolling(14).sum()
    d["tmean_3"], d["tmean_7"] = d["tmean"].rolling(3).mean(), d["tmean"].rolling(7).mean()
    d["melt_index"] = d["snow_14"] * (d["tmean_3"] > 0)
    doy = d["date"].dt.dayofyear
    d["doy_sin"], d["doy_cos"] = np.sin(2 * np.pi * doy / 365.25), np.cos(2 * np.pi * doy / 365.25)
    d["lat_n"] = lat / 90.0
    d["q_log"] = np.log1p(q.clip(lower=0))
    for c in ("precip", "rain", "snow"):
        d[f"{c}_l"] = np.log1p(d[c])
    # label: today is still below the level, but the river reaches it within the next 1-3 days
    fut = pd.concat([q.shift(-k) for k in range(1, HORIZON + 1)], axis=1).max(axis=1, skipna=False)
    d["y"] = ((fut >= 1) & (q < 1)).astype(float)
    d.loc[fut.isna(), "y"] = np.nan
    d["year"] = d["date"].dt.year
    return d


def make_sequences(d, seq_len=SEQ_LEN):
    arr = d[SEQ_COLS].to_numpy(dtype="float32")
    if len(arr) < seq_len:
        return np.empty((0, seq_len, len(SEQ_COLS)), "float32")
    return np.lib.stride_tricks.sliding_window_view(arr, (seq_len, arr.shape[1]))[:, 0]


# ---------------------------------------------------------------- models
def load_meta():
    p = MODEL_DIR / "meta.json"
    return json.loads(p.read_text()) if p.exists() else None


def load_xgb():
    from xgboost import XGBClassifier
    m = XGBClassifier()
    m.load_model(str(MODEL_DIR / "xgb.json"))
    return m


def load_lstm():
    import joblib
    from tensorflow import keras
    return keras.models.load_model(MODEL_DIR / "lstm.keras"), joblib.load(MODEL_DIR / "lstm_scaler.joblib")


def predict_xgb(model, d):
    return pd.Series(model.predict_proba(d[XGB_FEATURES])[:, 1], index=d.index)


def predict_lstm(bundle, d):
    model, scaler = bundle
    seqs = make_sequences(d)
    out = pd.Series(np.nan, index=d.index)
    if len(seqs):
        x = scaler.transform(seqs.reshape(-1, seqs.shape[2])).reshape(seqs.shape)
        out.iloc[SEQ_LEN - 1:] = model.predict(x, verbose=0, batch_size=1024).ravel()
    return out
