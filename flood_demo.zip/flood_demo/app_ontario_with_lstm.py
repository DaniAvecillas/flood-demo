import os
os.environ["FLOOD_REGION"] = "ontario"
from ui import run_app
run_app(enable_lstm=True)
