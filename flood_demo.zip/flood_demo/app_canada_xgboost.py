import os
os.environ["FLOOD_REGION"] = "canada"
from ui import run_app
run_app(enable_lstm=False)
