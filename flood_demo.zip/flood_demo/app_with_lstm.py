from ui import run_app
run_app(enable_lstm=True)
