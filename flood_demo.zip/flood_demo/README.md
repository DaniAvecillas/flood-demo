# Flood Risk Early-Warning Demo

Streamlit apps, same two demos each. Pick the region and the model version:

| Region (rivers)          | XGBoost only              | XGBoost + LSTM                |
|--------------------------|---------------------------|-------------------------------|
| World (27 rivers)        | app_xgboost.py            | app_with_lstm.py              |
| Canada (22 rivers)       | app_canada_xgboost.py     | app_canada_with_lstm.py       |
| Ontario (10 rivers)      | app_ontario_xgboost.py    | app_ontario_with_lstm.py      |

Demos: (1) check a river now (live data from Open-Meteo), (2) replay a past flood and see how many days before it the model raised an alert.

## Run (about 15-30 minutes the first time)
    pip install -r requirements.txt
    python 01_download_data.py --region canada     # weather + river flow 2002-2025, no API key
    python 02_train.py --region canada             # XGBoost + LSTM  (add --no-lstm for XGBoost only)
    streamlit run app_canada_xgboost.py            # or app_canada_with_lstm.py

Use `--region ontario` or `--region world` (or leave it out for world) the same way, with the matching app file.
Each river is downloaded once and shared between regions; models are saved in models/, models_canada/, models_ontario/.

## What the model predicts
Flood-risk event = the river reaches its own 98th-percentile flow within the next 1-3 days
(it was below that level today). River flow is simulated by GloFAS (via Open-Meteo), not measured
at a gauge, so the label is relative to each river, not an official flood stage.
Change `FLOOD_PCT` in floodlib.py (0.95 = more events, 0.99 = fewer) and re-run training.

## Tips for the video
- Run both scripts before recording. The app only loads saved models.
- Replay tab: pick events from the "unseen test years" (2022+): the model never saw them.
- Show one hit, one late alert and one miss. It looks more honest and your professor will notice.
- data/ is a backup: if the internet fails during recording, the live tab switches to saved data.
