"""Step 2: train one shared flood-risk model on all rivers.  Use --no-lstm to skip the LSTM."""
import json, sys
import numpy as np, pandas as pd
from sklearn.metrics import average_precision_score, precision_score, recall_score
from floodlib import *

use_lstm = "--no-lstm" not in sys.argv
MODEL_DIR.mkdir(exist_ok=True)

frames, thresholds = [], {}
for loc in LOCATIONS:
    f = DATA_DIR / f"{slug(loc['name'])}.csv"
    if not f.exists():
        continue
    d = clean(pd.read_csv(f, parse_dates=["date"]))
    thr = compute_threshold(d)
    if thr <= 0:
        continue
    thresholds[loc["name"]] = thr
    feats = make_features(d, thr, loc["lat"]); feats["loc"] = loc["name"]
    frames.append(feats)
assert frames, "No data found. Run 01_download_data.py first."
print(f"{len(frames)} locations loaded")

# ------------------------------------------------ XGBoost
all_df = pd.concat(frames, ignore_index=True)
tab = all_df[(all_df["q_ratio"] < 1) & all_df["y"].notna()].dropna(subset=XGB_FEATURES)
tr, va, te = (tab[tab.year <= TRAIN_END], tab[(tab.year > TRAIN_END) & (tab.year <= VAL_END)],
              tab[tab.year > VAL_END])
print(f"rows train/val/test: {len(tr)}/{len(va)}/{len(te)}; event rate train {tr.y.mean():.3%}")

from xgboost import XGBClassifier
xgb = XGBClassifier(n_estimators=600, learning_rate=0.05, max_depth=5, subsample=0.8,
                    colsample_bytree=0.8, eval_metric="aucpr", early_stopping_rounds=40,
                    tree_method="hist", n_jobs=-1, random_state=42)
xgb.fit(tr[XGB_FEATURES], tr.y, eval_set=[(va[XGB_FEATURES], va.y)], verbose=False)
xgb.save_model(str(MODEL_DIR / "xgb.json"))

def report(y, p):
    b = p >= WATCH
    return dict(pr_auc=round(float(average_precision_score(y, p)), 3),
                precision_at_watch=round(float(precision_score(y, b, zero_division=0)), 3),
                recall_at_watch=round(float(recall_score(y, b, zero_division=0)), 3))

meta = dict(
    region=REGION, flood_pct=FLOOD_PCT, horizon_days=HORIZON, seq_len=SEQ_LEN, watch=WATCH, warning=WARNING,
    split=f"train<= {TRAIN_END}, validation {TRAIN_END+1}-{VAL_END}, test >= {VAL_END+1}",
    n_locations=len(frames), test_event_rate=round(float(te.y.mean()), 4),
    thresholds=thresholds,
    baseline_river_only=dict(pr_auc=round(float(average_precision_score(te.y, te["q_ratio"])), 3)),
    xgb=report(te.y, xgb.predict_proba(te[XGB_FEATURES])[:, 1]), lstm=None)
print("XGBoost test:", meta["xgb"], "| baseline:", meta["baseline_river_only"])

# ------------------------------------------------ LSTM (optional)
if use_lstm:
    import joblib
    from sklearn.preprocessing import StandardScaler
    from tensorflow import keras
    keras.utils.set_random_seed(42)
    X, Y, YR = [], [], []
    for d in frames:
        d = d.dropna(subset=SEQ_COLS).reset_index(drop=True)
        seqs = make_sequences(d)
        end = d.iloc[SEQ_LEN - 1:].reset_index(drop=True)
        m = (end["y"].notna() & (end["q_ratio"] < 1)).to_numpy()
        X.append(seqs[m]); Y.append(end.loc[m, "y"].to_numpy()); YR.append(end.loc[m, "year"].to_numpy())
    X, Y, YR = np.concatenate(X), np.concatenate(Y), np.concatenate(YR)
    itr, iva, ite = YR <= TRAIN_END, (YR > TRAIN_END) & (YR <= VAL_END), YR > VAL_END
    scaler = StandardScaler().fit(X[itr].reshape(-1, X.shape[2]))
    Xs = scaler.transform(X.reshape(-1, X.shape[2])).reshape(X.shape).astype("float32")
    net = keras.Sequential([
        keras.layers.Input((SEQ_LEN, X.shape[2])),
        keras.layers.LSTM(32), keras.layers.Dropout(0.2),
        keras.layers.Dense(16, activation="relu"), keras.layers.Dense(1, activation="sigmoid")])
    net.compile("adam", "binary_crossentropy")
    net.fit(Xs[itr], Y[itr], validation_data=(Xs[iva], Y[iva]), epochs=20, batch_size=256, verbose=2,
            callbacks=[keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True)])
    net.save(MODEL_DIR / "lstm.keras"); joblib.dump(scaler, MODEL_DIR / "lstm_scaler.joblib")
    meta["lstm"] = report(Y[ite], net.predict(Xs[ite], verbose=0, batch_size=1024).ravel())
    print("LSTM test:", meta["lstm"])

(MODEL_DIR / "meta.json").write_text(json.dumps(meta, indent=2))
print("Saved models/ . Next: streamlit run app_xgboost.py   (or app_with_lstm.py)")
