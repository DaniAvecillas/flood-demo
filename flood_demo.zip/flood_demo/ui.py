"""Streamlit interface shared by both apps (with or without the LSTM)."""
import pandas as pd
import streamlit as st
from floodlib import *


@st.cache_resource
def get_models(enable_lstm):
    models = {"XGBoost": load_xgb()}
    if enable_lstm:
        models["LSTM"] = load_lstm()
    return models


def _predict(name, models, d):
    return predict_xgb(models[name], d) if name == "XGBoost" else predict_lstm(models[name], d)


@st.cache_data(show_spinner=False)
def saved_frame(loc_name, thr):
    loc = LOC_BY_NAME[loc_name]
    d = clean(pd.read_csv(DATA_DIR / f"{slug(loc_name)}.csv", parse_dates=["date"]))
    return make_features(d, thr, loc["lat"])


@st.cache_data(ttl=1800, show_spinner=False)
def live_frame(loc_name, thr):
    """Latest data from the internet; falls back to the saved CSV if the internet fails."""
    loc = LOC_BY_NAME[loc_name]
    try:
        d = clean(fetch_recent(loc["lat"], loc["lon"]))
        if len(d) < 25:
            raise RuntimeError("not enough days")
        return make_features(d, thr, loc["lat"]), True
    except Exception:
        return saved_frame(loc_name, thr).tail(40).reset_index(drop=True), False


@st.cache_data(show_spinner=False)
def all_probs(loc_name, thr, model_name, enable_lstm):
    return _predict(model_name, get_models(enable_lstm), saved_frame(loc_name, thr))


def band(p):
    if p >= WARNING:
        return ":red[HIGH]"
    if p >= WATCH:
        return ":orange[MEDIUM]"
    return ":green[LOW]"


def run_app(enable_lstm):
    st.set_page_config(page_title="Flood Risk Early-Warning Demo", page_icon="🌊", layout="wide")
    meta = load_meta()
    if meta is None:
        st.error("No trained models found. Run 01_download_data.py and 02_train.py first "
                 f"(for this app add: --region {REGION}).")
        st.stop()
    if enable_lstm and meta.get("lstm") is None:
        st.error("The LSTM was not trained. Run 02_train.py without --no-lstm.")
        st.stop()
    models = get_models(enable_lstm)
    thr_all = meta["thresholds"]
    names = [l["name"] for l in LOCATIONS if l["name"] in thr_all]

    st.title("🌊 Flood Risk Early-Warning Demo" + ("" if REGION == "world" else f" · {REGION_TITLE}"))
    st.caption(f"Predicts if a river will reach its own flood-risk level in the next {HORIZON} days "
               "from recent weather and river flow.")

    with st.sidebar:
        st.header("About the model")
        st.write(f"**Flood-risk level** = the {int(meta['flood_pct']*100)}th percentile of each "
                 "river's own flow (computed on training years only).")
        st.write(f"Trained on {meta['n_locations']} rivers. Split: {meta['split']}.")
        st.subheader("Test results (unseen years)")
        st.metric("River-only baseline, PR-AUC", meta["baseline_river_only"]["pr_auc"])
        for m in models:
            r = meta["xgb" if m == "XGBoost" else "lstm"]
            st.metric(f"{m}, PR-AUC", r["pr_auc"],
                      help=f"At the MEDIUM alert level: precision {r['precision_at_watch']}, "
                           f"recall {r['recall_at_watch']}")
        st.caption("PR-AUC: higher is better. Event rate in test years: "
                   f"{meta['test_event_rate']:.1%}.")
        st.warning("Demo only. River flow comes from a global model (GloFAS), not from a local "
                   "gauge. Do not use it for real safety decisions.")

    tab1, tab2 = st.tabs(["1 · Check a river now", "2 · Replay a past flood"])

    # ------------------------------------------------------------ demo 1
    with tab1:
        left, right = st.columns([1, 2])
        with left:
            name = st.selectbox("River / city", names, key="live_loc")
            thr = thr_all[name]
            loc = LOC_BY_NAME[name]
            st.write(f"📍 {loc['country']}  ·  flood-risk level: **{thr:,.0f} m³/s**")
        with right:
            pts = pd.DataFrame([{"lat": l["lat"], "lon": l["lon"],
                                 "color": "#e63946" if l["name"] == name else "#457b9d",
                                 "size": 250000 if l["name"] == name else 90000}
                                for l in LOCATIONS if l["name"] in thr_all])
            st.map(pts, latitude="lat", longitude="lon", color="color", size="size", height=260)

        with st.spinner("Getting the latest weather and river data..."):
            feats, is_live = live_frame(name, thr)
        today = feats.iloc[-1]
        if is_live:
            st.success(f"Live data up to {today['date']:%Y-%m-%d}")
        else:
            st.info(f"Offline mode: showing the last saved data ({today['date']:%Y-%m-%d}).")

        if today["q_ratio"] >= 1:
            st.error("The river is ALREADY above its flood-risk level today.")
        else:
            cols = st.columns(len(models))
            for col, m in zip(cols, models):
                p = float(_predict(m, models, feats).iloc[-1])
                with col:
                    st.subheader(m)
                    st.metric("Risk in the next 3 days", f"{p:.0%}")
                    st.progress(min(p / 0.5, 1.0))
                    st.markdown(f"Level: {band(p)}")
        c1, c2, c3 = st.columns(3)
        c1.metric("River flow today", f"{today['discharge']:,.0f} m³/s")
        c2.metric("Percent of flood-risk level", f"{today['q_ratio']:.0%}")
        c3.metric("Rain + snow, last 7 days", f"{today['precip_7']:.0f} mm")
        chart = feats.tail(30).set_index("date")[["discharge"]].rename(columns={"discharge": "River flow (m³/s)"})
        chart["Flood-risk level (m³/s)"] = thr
        st.line_chart(chart)

    # ------------------------------------------------------------ demo 2
    with tab2:
        c1, c2 = st.columns([1, 2])
        with c1:
            rname = st.selectbox("River / city", names, key="replay_loc")
            rthr = thr_all[rname]
        f = saved_frame(rname, rthr)
        onset = f[(f["q_ratio"] >= 1) & (f["q_ratio"].shift(1) < 1) & (f["year"] > TRAIN_END)]
        if onset.empty:
            st.info("No flood-risk events after 2017 for this river. Pick another one.")
            st.stop()
        labels = {}
        for i, row in onset.iterrows():
            peak = f.loc[i:i + 7, "discharge"].max()
            tag = "unseen test years" if row["year"] > VAL_END else "validation years"
            labels[f"{row['date']:%Y-%m-%d}  (peak {peak:,.0f} m³/s, {tag})"] = i
        with c2:
            pick = st.selectbox("Past event (the day the river passed its flood-risk level)",
                                list(labels), index=len(labels) - 1)
        i = labels[pick]
        win = f.iloc[max(0, i - 10): i + 6].set_index("date")
        event_day = f.loc[i, "date"]

        flow = win[["discharge"]].rename(columns={"discharge": "River flow (m³/s)"})
        flow["Flood-risk level (m³/s)"] = rthr
        st.subheader("What the river did")
        st.line_chart(flow)

        st.subheader("What the model said, day by day")
        risk = pd.DataFrame(index=win.index)
        for m in models:
            p = all_probs(rname, rthr, m, enable_lstm)
            p.index = f["date"]
            r = p.reindex(win.index)
            r[win.index >= event_day] = float("nan")      # after the event starts it is already high
            risk[f"{m} risk"] = r
        risk["MEDIUM level"], risk["HIGH level"] = WATCH, WARNING
        st.line_chart(risk)

        for m in models:
            pre = risk[f"{m} risk"].loc[event_day - pd.Timedelta(days=7): event_day - pd.Timedelta(days=1)]
            hit = pre[pre >= WATCH]
            if hit.empty:
                st.warning(f"{m}: no alert in the 7 days before this event (a missed event).")
            else:
                lead = (event_day - hit.index[0]).days
                first_high = pre[pre >= WARNING]
                extra = f", HIGH on {first_high.index[0]:%b %d}" if not first_high.empty else ""
                st.success(f"{m}: first alert on {hit.index[0]:%b %d}, {lead} day(s) before the "
                           f"river passed its flood-risk level{extra}.")
